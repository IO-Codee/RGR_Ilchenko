﻿
public abstract class $safeprojectname$
{
    public abstract void Operation(int extrinsicstate);
}


public class ConcreteFlyweight : $safeprojectname$
{
    public override void Operation(int extrinsicstate)
    {
        Console.WriteLine("ConcreteFlyweight: " + extrinsicstate);
    }
}


public class UnsharedConcreteFlyweight : $safeprojectname$
{
    public override void Operation(int extrinsicstate)
    {
        Console.WriteLine("UnsharedConcreteFlyweight: " + extrinsicstate);
    }
}


public class FlyweightFactory
{
    private Dictionary<string, $safeprojectname$> flyweights = new Dictionary<string, $safeprojectname$>();

    // Constructor
    public FlyweightFactory()
    {
        flyweights.Add("A", new ConcreteFlyweight());
        flyweights.Add("B", new ConcreteFlyweight());
        flyweights.Add("C", new ConcreteFlyweight());
    }

    public $safeprojectname$ GetFlyweight(string key)
    {
        return (($safeprojectname$)flyweights[key]);
    }
}

public class Program
{
    public static void Main()
    {
        // Arbitrary extrinsic state
        int extrinsicstate = 22;

        FlyweightFactory factory = new FlyweightFactory();

        // Work with different flyweight instances
        $safeprojectname$ fx = factory.GetFlyweight("A");
        fx.Operation(--extrinsicstate);

        $safeprojectname$ fy = factory.GetFlyweight("B");
        fy.Operation(--extrinsicstate);

        $safeprojectname$ fz = factory.GetFlyweight("C");
        fz.Operation(--extrinsicstate);

        UnsharedConcreteFlyweight fu = new UnsharedConcreteFlyweight();
        fu.Operation(--extrinsicstate);
    }
}
